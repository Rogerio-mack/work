#include <stdio.h>
#include <math.h>

int main() {
    printf("Medida do primeiro cateto: ");
    float cateto1;
    scanf("%f", &cateto1);
    printf("Medida do segundo cateto: ");
    float cateto2;
    scanf("%f", &cateto2);
    float hipotenusa = sqrt(cateto1*cateto1 + cateto2*cateto2);
    printf("Um triângulo retângulo com lados %f e %f tem uma hipotenusa igual a %f.\n", cateto1, cateto2, hipotenusa);
    return 0;
}