#include <stdio.h>

int main() {
    printf("Temperatura (em graus Celsius): ");
    float tempC;
    scanf("%f", &tempC);
    float tempF = 9.0/5.0 * tempC + 32;
    printf("Uma temperatura de %f graus Celsius equivale a %f graus Fahrenheit.\n", tempC, tempF);
    return 0;
}