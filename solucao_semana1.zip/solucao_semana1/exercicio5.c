#include <stdio.h>
#include <math.h>

int main() {
    printf("Raio do círculo: ");
    float raio;
    scanf("%f", &raio);
    float area = M_PI * raio * raio;
    printf("Um círculo com raio %f tem área igual a %f.\n", raio, area);
    return 0;
}